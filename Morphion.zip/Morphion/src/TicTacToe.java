import javax.swing.*; 
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TicTacToe extends JFrame implements ActionListener {

  private JButton[][] buttons = new JButton[3][3]; // [3]f toule [3]f l3ard;
  private boolean xTurn = true; // xTurn ze3la le tour dyal L X f le jeu

  public TicTacToe() {
    super("Tic-Tac-Toe");
    setSize(300, 300);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    setLayout(new GridLayout(3, 3)); // bach yrtab tol ou 3rad 3 3 msatrin
    initializeButtons();
    setVisible(true);
  }
  private void initializeButtons() {
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        buttons[i][j] = new JButton();
        buttons[i][j].setText("");
        buttons[i][j].addActionListener(new ButtonListener());
        add(buttons[i][j]);
      }
    }
  }
  
  
  

  private class ButtonListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      JButton buttonClicked = (JButton) e.getSource();
      if (buttonClicked.getText().equals("")) {
        if (xTurn) {
          buttonClicked.setText("X");
        } else {
          buttonClicked.setText("O");
        }
        xTurn = !xTurn;
      }
      checkForWin();
    }
  }

  private void checkForWin() {
    // check rows
    for (int i = 0; i < 3; i++) {
      if (checkRowCol(buttons[i][0].getText(), buttons[i][1].getText(), buttons[i][2].getText())) {
        JOptionPane.showMessageDialog(this, "Vous Avez gagné!");
        System.exit(0);
      }
    } 

    // check columns
    for (int i = 0; i < 3; i++) {
      if (checkRowCol(buttons[0][i].getText(), buttons[1][i].getText(), buttons[2][i].getText())) {
        JOptionPane.showMessageDialog(this, "Vous Avez gagné!");
        System.exit(0);
      }
    }

    // check diagonals
    if (checkRowCol(buttons[0][0].getText(), buttons[1][1].getText(), buttons[2][2].getText()) ||
        checkRowCol(buttons[0][2].getText(), buttons[1][1].getText(), buttons[2][0].getText())) {
      JOptionPane.showMessageDialog(this, "Vous Avez gagné!");
      System.exit(0);
    }
  }

  private boolean checkRowCol(String s1, String s2, String s3) {
    return (!s1.equals("") && s1.equals(s2) && s2.equals(s3));
  }

  public static void main(String [] args) {
      new TicTacToe(); // Create New Instance (Window) From Main Class
  }

@Override
public void actionPerformed(ActionEvent e) {
	// TODO Auto-generated method stub
	
}
}
